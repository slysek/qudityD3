import numpy as np
from qiskit.circuit import QuantumCircuit
from qiskit.quantum_info import Statevector, Operator
from qiskit.synthesis import TwoQubitWeylDecomposition
from qiskit.circuit.library import UnitaryGate

from QuditsOnQubitsv2.ghz_creator import create_basic_ghz


class QuditsOnQubits:
    def __init__(self, graph=None):
        if graph is None:

            self.circuit = create_basic_ghz()

    def brisbane(self):
        """Przykładowa metoda - kodowanie na Brisbane."""
        pass

    def torino(self):
        """Przykładowa metoda - kodowanie na Torino."""
        pass

    def fidelity(self, backend_name):
        """Przykładowa metoda - liczenie fidelity."""
        pass